import javax.swing.JFrame;

public class FirstFrame
{
	public static void main(String[] args)
	{
		JFrame frame = new JFrame("First Window");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setSize(480, 270);
		frame.setVisible(true);
		
	}
}