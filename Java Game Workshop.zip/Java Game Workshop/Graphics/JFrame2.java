import javax.swing.JFrame;
import java.awt.BorderLayout;


public class FirstFrame
{
	public static void main(String[] args)
	{
		JFrame frame = new JFrame("First Window");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setSize(480, 270);
		frame.setVisible(true);
		
		//new code
		MyPanel panel = new MyPanel();
		//adds panel to CENTER region
		frame.add(BorderLayout.CENTER, panel); 
	}
}