
public class World {

	public static void main(String[] args) {
		
		System.out.println("Hello, World");
		//create an object to access Phone class
		
		Phone myPhone = new Phone();
		
		myPhone.initialize(false, "Samsung");
		myPhone.describe();
		
		myPhone.togglePower();
		myPhone.upgrade(4.5);
		
		myPhone.describe();
		
		
	}

}
