//These variables describe the Phone object's state
	private boolean poweredOn;
	private boolean playingMusic = false;
	private String phoneManufacturer;
	private double androidVersionNumber = 4.4;

	//These methods are the phone object's behaviors
	void togglePower()
	{
		if(poweredOn)
		{
			System.out.println("Powering Off");
			poweredOn = false;
			playingMusic = false;
		}
		else
		{
			System.out.println("Powering On!");
			poweredOn = true;
		}

	} //end of togglePower method

	void playMusic()
	{
		if (poweredOn)
		{
			System.out.println("Playing Music");
			playingMusic = true;
		}
	}//ends playMusic method

	void upgrade(double newVersion)
	{
		if(newVersion > androidVersionNumber)
		{
			androidVersionNumber = newVersion;
		}
		else
		{
			System.out.println("Upgrade failed!");
		}
	}//end of upgrade method