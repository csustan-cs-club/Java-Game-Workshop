//These variables describe the Phone object's state
	private boolean poweredOn;
	private boolean playingMusic = false; //declare a value
	private String phoneManufacturer;
	private double androidVersionNumber = 4.4; //declare a value

	//These methods are the phone object's behaviors
	
	//new method to be added
	void initialize(boolean poweredOn, String phoneManufacturer)
	{
		this.poweredOn = poweredOn;
		this.phoneManufacturer = phoneManufacturer;
	}
	
	void togglePower()
	{
		if(poweredOn)
		{
			System.out.println("Powering Off");
			poweredOn = false;
			playingMusic = false;
		}
		else
		{
			System.out.println("Powering On!");
			poweredOn = true;
		}

	} //end of togglePower method

	void playMusic()
	{
		if (poweredOn)
		{
			System.out.println("Playing Music");
			playingMusic = true;
		}
	}//ends playMusic method

	void upgrade(double newVersion)
	{
		if(newVersion > androidVersionNumber)
		{
			androidVersionNumber = newVersion;
		}
		else
		{
			System.out.println("Upgrade failed!");
		}
	}//end of upgrade method
	
	
	//new method to be added
	void describe()
	{
		System.out.println("myPhone's state: ");
		System.out.println("Powered on: " +poweredOn);
		System.out.println("Playing music: " +playingMusic);
		System.out.println("Phone Manufactuer: " +phoneManufacturer);
		System.out.println("Android Version Number: " +androidVersionNumber); 
	}