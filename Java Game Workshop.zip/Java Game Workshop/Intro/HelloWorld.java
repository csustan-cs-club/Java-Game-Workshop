public class World{
	public static void main(String[] args)
	{
		System.out.println("Hello, World");
		Phone myPhone = new Phone();
		myPhone.poweredOn = true;
		myPhone.playingMusic = false;
		myPhone.phoneManufacturer = "Samsung";
		myPhone.androidVersionNumber = 4.4;

		System.out.println("myPhone's state: ");
		System.out.println("Powered on: " +myPhone.poweredOn);
		System.out.println("Playing music: " +myPhone.playingMusic);
		System.out.println("Phone Manufactuer: " +myPhone.phoneManufacturer);
		System.out.println("Android Version Number: " +myPhone.androidVersionNumber); 

	}
}