myPhone.togglePower();
myPhone.upgrade(4.5);

System.out.println("\nmyPhone's New state: ");
System.out.println("Powered on: " +myPhone.poweredOn);
System.out.println("Playing music: " +myPhone.playingMusic);
System.out.println("Phone Manufactuer: " +myPhone.phoneManufacturer);
System.out.println("Android Version Number: " +myPhone.androidVersionNumber); 