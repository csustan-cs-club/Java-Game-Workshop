Coder c = new Coder("Anthony", 21);
c.describe();
System.out.println("");

String cname = c.getName();
int cAge = c.getAge();

System.out.println(cname + ", " + cAge);
System.out.println("");
c.setName("Alex");
c.setAge(-5); //our setter should reject this

c.describe();