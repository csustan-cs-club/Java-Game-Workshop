public String getName()
{
	return name;
}

public int getAge()
{
	return age;
}

public void setName(String newName)
{
	if(newName != null)
	{
		name = newName;
	}
	else
	{
		System.out.println("Invalid name provided!");
	}
}

public void setAge(int newAge)
{
	if(newAge > 0)
	{
		age = newAge;
	}
	else{
		System.out.println("Invalid age provided!");
	}
}