Coder c = new Coder();
c.describe();

System.out.println("");
c.initialize("Anthony", 21);
c.describe();