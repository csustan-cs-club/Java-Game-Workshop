ArrayList<Person> people = new ArrayList<Person>();
Random r = new Random();

for(int i = 0; i < 5; i++)
{
	Person p = new Person();
	p.initialize("Person #" +i, r.nextInt(50));
	people.add(p);
}

for (int i = 0; i < people.size(); i++)
{
	Person p = people.get(i);
	p.describe();
}