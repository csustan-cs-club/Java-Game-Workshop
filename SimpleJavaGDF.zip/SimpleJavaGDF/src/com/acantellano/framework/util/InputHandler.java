package com.acantellano.framework.util;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import com.acantellano.game.state.State;

public class InputHandler implements MouseListener, KeyListener {
	
	private State currentState;

	@Override
	public void keyPressed(KeyEvent e) {
		
		currentState.onKeyPress(e);
		
	}

	@Override
	public void keyReleased(KeyEvent e) {
		
		currentState.onKeyRelease(e);
		
	}

	@Override
	public void keyTyped(KeyEvent e) {
		// not needed
		
	}

	@Override
	public void mouseClicked(MouseEvent e) {
		
		currentState.onClick(e);
	}

	@Override
	public void mouseEntered(MouseEvent e) {
		// not needed
		
	}

	@Override
	public void mouseExited(MouseEvent e) {
		// not needed
		
	}

	@Override
	public void mousePressed(MouseEvent e) {
		// not needed
		
	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// not needed
		
	}
	public void setCurrentState(State currentState)
	{
		this.currentState = currentState;
	}

}
