package com.acantellano.game.state;

import java.awt.Graphics;
import java.awt.event.KeyEvent;
import java.awt.event.MouseEvent;

import com.acantellano.game.main.Resources;

public class MenuState extends State{

	@Override
	public void init() {
		
		System.out.print("Entered MenuState");
		
	}

	@Override
	public void update() {
		
		
	}

	@Override
	public void render(Graphics g) {
		// draws Resources.welcome to the screen at x =0; y = 0;
		g.drawImage(Resources.welcome, 0, 0, null);
		
		
	}

	@Override
	public void onClick(MouseEvent e) {
		// TODO Auto-generated method stub
		System.out.println("Mouse clicked");
		
	}

	@Override
	public void onKeyPress(KeyEvent e) {
		// TODO Auto-generated method stub
		System.out.println("Key pressed");
		
	}

	@Override
	public void onKeyRelease(KeyEvent e) {
		// TODO Auto-generated method stub
		System.out.println("Key released");

		
	}

}
