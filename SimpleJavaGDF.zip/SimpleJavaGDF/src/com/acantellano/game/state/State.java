package com.acantellano.game.state;

import java.awt.Graphics;
import java.awt.event.KeyEvent;
import java.awt.event.MouseEvent;

import com.acantellano.game.main.GameMain;

//when we use abstract, we can create methods, but the class
//that uses them, must implement them. EX. the MenuState implements the methods
public abstract class State {
	
	public abstract void init(); //this will be called when we transition into a new state
	
	public abstract void update();//will be called by the game loop on every frame
	
	public abstract void render(Graphics g); //renders game images to screen
	
	public abstract void onClick(MouseEvent e); //listens for mouse clicks
	
	public abstract void onKeyPress(KeyEvent e); //listens for keyboard clicks
	
	public abstract void onKeyRelease(KeyEvent e); //called when key is released
	
	//forgot to add this method
	public void setCurrentState(State newState)
	{
		GameMain.sGame.setCurrentState(newState);
	}

}
