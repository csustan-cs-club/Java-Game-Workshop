package com.acantellano.game.main;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Image;

import javax.swing.JPanel;

import com.acantellano.framework.util.InputHandler;
import com.acantellano.game.state.LoadState;
import com.acantellano.game.state.State;

@SuppressWarnings("serial")
public class Game extends JPanel implements Runnable{
	//instance variables
	private int gameWidth;
	private int gameHeight;
	private Image gameImage;

	private Thread gameThread;
	private volatile boolean running;
	private volatile State currentState;

	private InputHandler inputHandler;

	//our default constructor that we made
	public Game(int gameWidth, int gameHeight)
	{
		this.gameWidth = gameWidth; //this instance of gameWidth, set it equal to the gameWidth variable in our constructor
		this.gameHeight = gameHeight;
		setPreferredSize(new Dimension(gameWidth, gameHeight));
		setBackground(Color.BLACK);
		setFocusable(true); //prepares for input
		requestFocus(); //prepares for input
	}
	
	//sets our states
	public void setCurrentState(State newState)
	{
		System.gc(); //gets rid of any unused objects
		newState.init();
		currentState = newState; //these 2 needed to be switched, that got rid of the exceptions
		inputHandler.setCurrentState(currentState);

	}

	@Override
	public void addNotify()
	{
		super.addNotify();
		initInput();
		setCurrentState(new LoadState());
		initGame(); //forgot to call initGame()
	}
	
	private void initGame(){
		running = true;
		gameThread = new Thread(this, "Game Thread");
		gameThread.start();
	}
	
	@Override //forgot this line
	public void run()
	{
		while(running)
		{
			currentState.update();
			prepareGameImage();
			currentState.render(gameImage.getGraphics());
			repaint();
			try{
				Thread.sleep(14);
			}catch(InterruptedException e)
			{
				e.printStackTrace();
			}
		}
		System.exit(0);
	}
	
	private void prepareGameImage()
	{
		if(gameImage == null)
		{
			gameImage = createImage(gameWidth, gameHeight);
		}
		Graphics g = gameImage.getGraphics();
		g.clearRect(0, 0, gameWidth, gameHeight);
	}
	
	public void exit()
	{
		running = false;
	}

	@Override
	public void paintComponent(Graphics g)
	{
		super.paintComponent(g);
		if(gameImage == null)
		{
			return;
		}
		g.drawImage(gameImage, 0, 0, null);
	}

	public void initInput()
	{
		inputHandler = new InputHandler();
		addKeyListener(inputHandler);
		addMouseListener(inputHandler);
	}
}
