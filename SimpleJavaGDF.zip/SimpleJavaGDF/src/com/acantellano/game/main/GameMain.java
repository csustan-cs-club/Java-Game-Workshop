package com.acantellano.game.main;

import javax.swing.JFrame;

import com.acantellano.game.state.State;
public class GameMain {
	private static final String GAME_TITLE = "Java Game Framework";
	public static final int GAME_HEIGHT = 450;
	public static final int GAME_WIDTH = 800;
	public static Game sGame;

	public static void main(String[] args) {
		JFrame frame = new JFrame(GAME_TITLE);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); //kills the window when we hit the 'x' to close it
		frame.setResizable(false); //doesn't alow window resizing
		sGame = new Game(GAME_WIDTH, GAME_HEIGHT);
		frame.add(sGame);
		frame.pack(); //tells our JFrame object to resize to accomodate the preferred size of the contents
		frame.setVisible(true); //need this line for the window to show up
		frame.setIconImage(Resources.iconimage);
	
		

	}
	/*
	 * This method does not belong here
	public void setCurrentState(State newState)
	{
		GameMain.sGame.setCurrentState(newState);
	}
	 */
}
