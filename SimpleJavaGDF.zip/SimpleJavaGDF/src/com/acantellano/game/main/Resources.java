package com.acantellano.game.main;

import java.applet.Applet;
import java.applet.AudioClip;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.net.URL;

//import javax.annotation.Resource; //we dont need this import
import javax.imageio.ImageIO;

public class Resources {

	public static BufferedImage welcome, iconimage;

	//this method loads the resources
	public static void load()
	{
		welcome = loadImage("welcome.png");
		iconimage = loadImage("iconimage.png");
	}
	
	//helper method to retrieve Audio
	private static AudioClip loadSound(String filename)
	{
		URL fileURL = Resources.class.getResource("/resources/" +filename);
		return Applet.newAudioClip(fileURL);
	}
	
	//helper method to retrieve Images
	private static BufferedImage loadImage(String filename)
	{
		BufferedImage img = null;
		try {
			img = ImageIO.read(Resources.class.getResourceAsStream("/resources/" +filename));
		} catch (IOException e) {
			System.out.println("Error while reading" +filename);//used for debugging
			e.printStackTrace();
		}
		return img;
	}

}
