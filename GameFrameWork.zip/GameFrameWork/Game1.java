package com.acantellano.game.main;

import javax.swing.JPanel;

@SuppressWarnings("serial")

public class Game extends JPanel{
	
}