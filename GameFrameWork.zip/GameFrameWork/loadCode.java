public static BufferedImage welcome, iconimage;

public static void load()
{
	welcome = loadImage("welcome.png");
	iconimage = loadImage("iconimage.png");
}